export default {
    REQUEST_URL: '',
}